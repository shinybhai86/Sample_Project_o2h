//
//  ViewController.swift
//  Sample Project
//

import UIKit
import GoogleSignIn
import Firebase

class LoginViewController: UIViewController {
    
    // MARK: - IBoutlets
    
    @IBOutlet weak var btnLoginBackground: UIView!
    @IBOutlet weak var contentBg: UIView!
    
    // Instance of UiviewController
    class func instance() -> LoginViewController? {
        return Storyboard.Main.storyboard().instantiateViewController(withIdentifier: StoryboardId.LoginViewcontroller.storyboardId()) as? LoginViewController
    }

    // MARK: - View Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
    }
    
    // MARK: - Set Up
    
    private func initialSetUp() {
        GlobalUtility.showHud()
        contentBg.layer.cornerRadius = 20
        self.navigationController?.navigationBar.isHidden = true
        self.navigationItem.hidesBackButton = true
        btnLoginBackground.layer.cornerRadius = 10
        if GIDSignIn.sharedInstance.hasPreviousSignIn() {
            print("Navigating to home screen")
            navToHomeVc()
        } else {
            print("No login is there")
        }
        GlobalUtility.hideHud()
    }
    
    func navToHomeVc() {
        if let vc = GalleryViewController.instance() {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    // Storing data after the initial login
    func storeUserDataAfterLogin(image: String, email: String, fullName: String) {
        let defaults = UserDefaults.standard
        defaults.set(image, forKey: "user_image")
        defaults.set(email, forKey: "user_email")
        defaults.set(fullName, forKey: "user_full_name")
    }
    
    // MARK: - Method to E-Mail login
    func getEMailLogIn() {
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { result, error in
            guard error == nil else { return }
            if let result = result {
                self.storeUserDataAfterLogin(image: "\((result.user.profile?.imageURL(withDimension: 100))!)", email: result.user.profile?.email ?? "", fullName: result.user.profile?.name ?? "")
                print("Email: \(String(describing: result.user.profile?.email))")
                if let vc = GalleryViewController.instance() {
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    }
    
    // MARK: - IBActions

    @IBAction func btnGoogleLoginAction(_ sender: UIButton) {
        if InternetConnectionManager.isConnectedToNetwork() {
            getEMailLogIn()
        } else {
            let alert = UIAlertController(title: "Sample Project", message: "No internet connection", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "Ok", style: .cancel) { _ in
                self.dismiss(animated: true)
            }
            alert.addAction(action1)
            self.present(alert, animated: true)
        }
    }
}
