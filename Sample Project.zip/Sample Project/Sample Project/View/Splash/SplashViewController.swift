//
//  SplashViewController.swift
//  Sample Project
//

import UIKit

class SplashViewController: UIViewController {

    // MARK: - View Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
    }
    
    // MARK: - Set Up
    
    private func initialSetUp() {
        
        // Wait for few sceonds and push to login
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            if let vc = LoginViewController.instance() {
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }

}
