//
//  ProfileViewController.swift
//  Sample Project
//

import UIKit
import GoogleSignIn
import Kingfisher

class ProfileViewController: UIViewController {
    
    // MARK: - IBoutlets
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var btnLogoutBg: UIView!
    @IBOutlet weak var contentBg: UIView!
    
    /// Variables
    
    // Instance of UiviewController
    class func instance() -> ProfileViewController? {
        return Storyboard.Main.storyboard().instantiateViewController(withIdentifier: StoryboardId.ProfileViewController.storyboardId()) as? ProfileViewController
    }
    
    // MARK: - View Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
        retrieveUserDataForLogin()
    }
    
    // MARK: - Set Up
    
    private func initialSetUp() {
        contentBg.layer.cornerRadius = 20
        btnLogoutBg.layer.cornerRadius = btnLogoutBg.frame.height / 2
        imgProfile.layer.cornerRadius = imgProfile.frame.height / 2
    }
    
    // Retrieving data during a subsequent login
    func retrieveUserDataForLogin() {
        let defaults = UserDefaults.standard
        if let storedImage = defaults.string(forKey: "user_image"),
           let storedEmail = defaults.string(forKey: "user_email"),
           let storedFullName = defaults.string(forKey: "user_full_name") {
            lblEmail.text = storedEmail
            lblUsername.text = storedFullName
            imgProfile.kf.setImage(with: URL(string: storedImage))
        }
    }
    
    // MARK: - Method to E-Mail Logout
    
    func getGmailLogOut() {
        let alert = UIAlertController(title: "Sample Project", message: "Click ok to logout!", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "Ok", style: .default) { _ in
            GlobalUtility.showHud()
            UserDefaults.standard.removeObject(forKey: "image_data")  // Remove stored images
            UserDefaults.standard.setValue(false, forKey: "have_image_data")
            if let viewControllers = self.navigationController?.viewControllers {
                for viewController in viewControllers {
                    GIDSignIn.sharedInstance.signOut()
                    GlobalUtility.hideHud()
                    if viewController is LoginViewController {  // Push back to login
                        self.navigationController?.popToViewController(viewController, animated: true)
                    }
                }
            }
        }
        let action2 = UIAlertAction(title: "Cancel", style: .default) { _ in
            self.dismiss(animated: true)
        }
        alert.addAction(action2)
        alert.addAction(action1)
        self.present(alert, animated: true)
        
    }
    
    // MARK: - IBActions
    
    @IBAction func btnLogoutAction(_ sender: UIButton) {
        if GIDSignIn.sharedInstance.currentUser?.profile?.email != "" {
            self.getGmailLogOut()
        }
    }
    
    @IBAction func btnBackTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}
