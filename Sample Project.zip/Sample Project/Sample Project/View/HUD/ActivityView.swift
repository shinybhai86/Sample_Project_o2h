
import UIKit
import Lottie

class ActivityView: UIView {
    
    fileprivate var animationView = LottieAnimationView()
    
    var animationFile = "loading"
    
    public static var sharedActivity: ActivityView? = {
        let shared = ActivityView.instanceFromNib()
        return shared
    }()
    
    class func instanceFromNib() -> ActivityView? {
        if let activityView = UINib(nibName: "ActivityView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as? ActivityView {
            activityView.frame = UIScreen.main.bounds
            activityView.center = APP_DELEGATE.window?.center ?? activityView.center
            activityView.animationView = LottieAnimationView(name: activityView.animationFile)
            let expectedWidth: CGFloat = 100
            let expectedHeight: CGFloat = 100
            activityView.animationView.frame = CGRect(x: 0, y: 0, width: expectedWidth, height: expectedHeight)
            activityView.animationView.contentMode = .scaleToFill
            activityView.animationView.loopMode = LottieLoopMode.loop
            activityView.addSubview(activityView.animationView)
            activityView.animationView.center = activityView.center
            
            return activityView
        }
        return nil
    }
    
    func show() {
        animationView.play()
        UIApplication.shared.windows.last?.addSubview(self)
    }
    
    func hide() {
        animationView.stop()
        self.removeFromSuperview()
    }
}
