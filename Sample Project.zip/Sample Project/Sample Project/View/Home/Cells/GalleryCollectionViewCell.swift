//
//  GalleryCollectionViewCell.swift
//  Sample Project
//

import UIKit
import Kingfisher

class GalleryCollectionViewCell: UICollectionViewCell {

    // MARK: - IBOutlets
    
    @IBOutlet weak var imgSample: UIImageView!
    
    /// Variables
    static var identifier = String(describing: GalleryCollectionViewCell.self)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func getValues(_ obj: ImageData) {
        imgSample.kf.setImage(with: URL(string: obj.imageUrl ?? "")!)
    }
}
