//
//  GalleryViewController.swift
//  Sample Project
//

import UIKit

class GalleryViewController: UIViewController {
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var collectionImages: UICollectionView!
    
    /// Variables
    var getImageData = [ImageData]()
    var timer = Timer()
    
    // Instance of UiviewController
    class func instance() -> GalleryViewController? {
        return Storyboard.Main.storyboard().instantiateViewController(withIdentifier: StoryboardId.GalleryViewController.storyboardId()) as? GalleryViewController
    }
    
    // MARK: - View Controller lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetUp()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        fetchImageData()
    }
    
    // MARK: - Set Up
    
    private func initialSetUp() {
        
        // Register tableview cell
        collectionImages.register(UINib(nibName: GalleryCollectionViewCell.identifier, bundle: .main), forCellWithReuseIdentifier: GalleryCollectionViewCell.identifier)
        self.navigationController?.navigationBar.isHidden = true
        fetchImageData() // Get image data
        
        // Add refresh to collection view
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(getReloadData(_:)), for: .valueChanged)
        collectionImages.refreshControl = refresh
        
        // Scedhule a timer to check we have internet connetion
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateCounting), userInfo: nil, repeats: true)
    }
    
    @objc func updateCounting(){
        if InternetConnectionManager.isConnectedToNetwork() {
            print("Connected")
        } else {
            let alert = UIAlertController(title: "Sample Project", message: "No internet connection, click ok to see offline images", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "Ok", style: .default) { _ in
                self.timer.invalidate()
                self.fetchImageData()
            }
            let action2 = UIAlertAction(title: "Cancel", style: .default) { _ in
                self.dismiss(animated: true)
            }
            alert.addAction(action2)
            alert.addAction(action1)
            self.present(alert, animated: true)
        }
    }
    
    // Action for refresh control
    @objc func getReloadData(_ sender: UIRefreshControl) {
        if sender.isRefreshing {
            fetchImageData()
        }
        sender.endRefreshing()
    }
    
    // Get image data from json file
    func fetchImageData() {
        GlobalUtility.showHud()
        if InternetConnectionManager.isConnectedToNetwork(){
            let url = Bundle.main.url(forResource: "data", withExtension: "json")! // Decode the data from json file
            guard let data = try? Data(contentsOf: url) else { return  }
            let imageData = try? JSONDecoder().decode(ImageListModel.self, from: data)
            if let imageData = imageData {
                self.getImageData = imageData.images ?? [ImageData]() // Save the data
                let dataEncode = try? JSONEncoder().encode(imageData)
                UserDefaults.standard.set(dataEncode, forKey: "image_data")
                UserDefaults.standard.setValue(true, forKey: "have_image_data")
            }
            print("Connected")
        } else {
            if UserDefaults.standard.bool(forKey: "have_image_data") == true {
                let offlineData = UserDefaults.standard.data(forKey: "image_data")
                let decodeData = try? JSONDecoder().decode(ImageListModel.self, from: offlineData!)
                self.getImageData = decodeData?.images ?? [ImageData]() // Save the data
            }
        }
        DispatchQueue.main.async {
            self.collectionImages.reloadData()
            self.collectionImages.collectionViewLayout.invalidateLayout()
        }
        GlobalUtility.hideHud()
    }
    
    // MARK: - IBActions
    
    @IBAction func btnProfileTapped(_ sender: UIButton) {
        if let vc = ProfileViewController.instance() {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
