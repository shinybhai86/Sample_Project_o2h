//
//  ImageListModel.swift
//  Sample Project
//

import Foundation

struct ImageListModel : Codable {

    let images : [ImageData]?

    enum CodingKeys: String, CodingKey {
        case images = "images"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        images = try values.decodeIfPresent([ImageData].self, forKey: .images)
    }

}

struct ImageData : Codable {

    let imageUrl : String?

    enum CodingKeys: String, CodingKey {
        case imageUrl = "image_url"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        imageUrl = try values.decodeIfPresent(String.self, forKey: .imageUrl)
    }

}
