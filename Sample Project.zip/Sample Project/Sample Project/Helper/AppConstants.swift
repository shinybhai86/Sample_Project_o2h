//
//  AppConstants.swift
//  Sample Project
//

import Foundation
import UIKit

let APP_DELEGATE = UIApplication.shared.delegate as? AppDelegate ?? AppDelegate()

public enum Storyboard: String {
    case Main
    
    func storyboard() -> UIStoryboard {
        return UIStoryboard(name: self.rawValue, bundle: .main)
    }
}

public enum StoryboardId: String {
    case LoginViewcontroller
    case GalleryViewController
    case ProfileViewController
    
    func storyboardId() -> String {
        return ("k\(self.rawValue)")
    }
}
